package pageObjects;

import org.openqa.selenium.WebDriver;

public class HomePage extends NavbarPage {

	public HomePage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	
	
}
